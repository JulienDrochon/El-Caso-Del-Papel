[![Bare Conductive](http://bareconductive.com/assets/images/LOGO_256x106.png)](http://www.bareconductive.com/)

# Bare Conductive Keyboard Emulation

Code for the  [Bare Conductive Pi Cap](http://www.bareconductive.com/shop/pi-cap/). Allows you to emulate a keyboard and map keyboard strokes to the Pi Cap's electrodes. This code example hasn't been created in Node.js yet. You can use the [Pi Cap Python Keyboard Emulaton](https://github.com/BareConductive/picap-keyboard-py) in the meantime.